# Server Konfiqurasiya Pəncərəsi - UI Diaqramı

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  🔙  Server Konfiqurasiyası                                    🔄    ⋮      │
│                                    (Refresh)            (More Options)      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  🌐                                                                 │   │
│  │  Hybrid Infrastructure                                             │   │
│  │  Öz sistemlərlə Azure arasında switch edin                         │   │
│  │                                                                     │   │
│  │  ┌────────────────────────────┐                                    │   │
│  │  │ ✅ Default: Pulsuz ($0/ay) │  ← Yasil badge ( gradient )       │   │
│  │  └────────────────────────────┘                                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              (Blue Gradient Card)                           │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  🖥️  CARI STATUS                                                   │   │
│  │  ─────────────────────────────────────────────────────────────     │   │
│  │                                                                     │   │
│  │  Messaging:                              ┌──────────────┐          │   │
│  │  🗄️ (icon)                               │ Öz Sistem    │ ← Yasil  │   │
│  │  (SQL Server icon)                       │ (green badge)│          │   │
│  │                                          └──────────────┘          │   │
│  │                                                                     │   │
│  │  Monitoring:                             ┌──────────────┐          │   │
│  │  🗄️ (icon)                               │ Öz Sistem    │ ← Yasil  │   │
│  │  (SQL Server icon)                       │ (green badge)│          │   │
│  │                                          └──────────────┘          │   │
│  │  ─────────────────────────────────────────────────────────────     │   │
│  │  💰 Aylıq Xərc:                    $0/ay (Yasil = pulsuz)          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              (White Card)                                   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  💬  MESSAGING SİSTEMİ                                    Öz Sistem │   │
│  │  ─────────────────────────────────────────────────────────────     │   │
│  │                                                                     │   │
│  │  📦 SQL Server Message Queue                                        │   │
│  │  • Lokal database-də saxlanılır                                    │   │
│  │  • 5000 user-ə qədər kifayət edir                                  │   │
│  │  • Pulsuz                                                          │   │
│  │                                                                     │   │
│  │  ┌─────────────────────────────────────────────────────────────┐   │   │
│  │  │  ☁️ Azure-a Keç                                              │   │   │
│  │  │  (icon)                                                      │   │   │
│  │  │  Mavi button - Azure-a kecmek ucun                          │   │   │
│  │  └─────────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              (Purple accent card)                           │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  📊  MONITORING SİSTEMİ                                   Öz Sistem │   │
│  │  ─────────────────────────────────────────────────────────────     │   │
│  │                                                                     │   │
│  │  📈 SQL Server Monitoring                                           │   │
│  │  • Lokal database-də log-lar                                       │   │
│  │  • 100GB-ə qədər kifayət edir                                      │   │
│  │  • Pulsuz                                                          │   │
│  │                                                                     │   │
│  │  ┌─────────────────────────────────────────────────────────────┐   │   │
│  │  │  ☁️ Azure-a Keç                                              │   │   │
│  │  │  (icon)                                                      │   │   │
│  │  │  Mavi button - Azure-a kecmek ucun                          │   │   │
│  │  └─────────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              (Orange accent card)                           │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  💳  XƏRC MÜQAYİSƏSİ                                               │   │
│  │  ─────────────────────────────────────────────────────────────     │   │
│  │                                                                     │   │
│  │  ⭐ Öz + Öz                    $0/ay      ✅ 5000 user-ə qədər      │   │
│  │                                                                     │   │
│  │     Öz + Azure Monitoring      $200/ay    100GB+ log                │   │
│  │                                                                     │   │
│  │     Azure Messaging + Öz       $30/ay     10,000+ msg/s             │   │
│  │                                                                     │   │
│  │     Azure + Azure              $230/ay    Enterprise scale          │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              (Grey background card)                         │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  ⚠️  VACİB QEYDLƏR                                                 │   │
│  │                                                                     │   │
│  │  • Switch etdikdən sonra server restart tələb olunur               │   │
│  │  • Azure-a keçməzdən əvvəl connection string əlavə edin            │   │
│  │  • Geri qayıtma həmişə mümkündür (pulsuz)                          │   │
│  │  • SuperAdmin icazəsi tələb olunur                                 │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              (Orange warning card)                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
                              (Pull-to-refresh)
```

---

## 🔄 Azure-a Keçəndə Nələr Dəyişir:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         AZURE-A KEÇİŞ DİALOQU                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ☁️  Messaging Dəyişdirilsin?                                               │
│                                                                             │
│  Azure-a keçmək istəyirsiniz?                                               │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  ⚠️  Bu əməliyyat aylıq ödəniş tələb edə bilər!                   │   │
│  │      (Orange warning box)                                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  ℹ️  Server restart tələb olunacaq                                 │   │
│  │      (Blue info box)                                               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌────────────┐    ┌────────────────────────────────────────────────┐      │
│  │  Ləğv et  │    │  ☁️ Azure-a Keç                                 │      │
│  │  (Text)   │    │  (Blue ElevatedButton)                         │      │
│  └────────────┘    └────────────────────────────────────────────────┘      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 📊 Öz Sistemə Qayıdanda:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      ÖZ SİSTEMƏ QAYITMA DİALOQU                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  🗄️  Messaging Dəyişdirilsin?                                               │
│                                                                             │
│  Öz sisteminə qayıtmaq istəyirsiniz?                                        │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  ℹ️  Server restart tələb olunacaq                                 │   │
│  │      (Blue info box)                                               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌────────────┐    ┌────────────────────────────────────────────────┐      │
│  │  Ləğv et  │    │  🗄️ Öz Sistemə Qayıt                            │      │
│  │  (Text)   │    │  (Green ElevatedButton)                        │      │
│  └────────────┘    └────────────────────────────────────────────────┘      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🎨 Rəng Kodları:

| Element | Rəng | Mənası |
|---------|------|--------|
| 🟢 **Yasil** | `Colors.green` | Öz sistem (pulsuz) |
| 🔵 **Mavi** | `Colors.blue` | Azure (bulud) |
| 🟠 **Narıncı** | `Colors.orange` | Xəbərdarlıq / Xərc |
| 🔴 **Qırmızı** | `Colors.red` | Xəta |
| ⚪ **Ağ/Grey** | `Colors.grey` | Neutrallıq |
| ⭐ **Sarı** | `Colors.amber` | Tövsiyə edilən |

---

## 🔄 State'ların Dəyişmə Diyagramı:

```
┌─────────────────┐         ┌─────────────────┐
│   LOADING       │ ──────► │    SUCCESS      │
│  (Circular      │         │  (Data shown)   │
│   Progress)     │         │                 │
└─────────────────┘         └────────┬────────┘
         │                           │
         │                           │
         ▼                           ▼
┌─────────────────┐         ┌─────────────────┐
│     ERROR       │ ◄────── │  USER ACTION    │
│  (Red card      │         │  (Switch button)│
│   with message) │         │                 │
└─────────────────┘         └────────┬────────┘
                                     │
                                     ▼
                            ┌─────────────────┐
                            │   DIALOG SHOWN  │
                            │  (Confirmation) │
                            └────────┬────────┘
                                     │
                    ┌────────────────┼────────────────┐
                    │                                 │
                    ▼                                 ▼
            ┌───────────────┐                ┌───────────────┐
            │  CANCELLED    │                │  CONFIRMED    │
            │  (Close dialog)│               │  (API call)   │
            └───────────────┘                └───────┬───────┘
                                                     │
                                                     ▼
                                            ┌─────────────────┐
                                            │  LOADING DIALOG │
                                            │  (Blocking UI)  │
                                            └────────┬────────┘
                                                     │
                                    ┌────────────────┼────────────────┐
                                    │                                 │
                                    ▼                                 ▼
                           ┌───────────────┐                 ┌───────────────┐
                           │    SUCCESS    │                 │     ERROR     │
                           │ (SnackBar     │                 │  (SnackBar    │
                           │  green)       │                 │   red)        │
                           └───────────────┘                 └───────────────┘
```

---

## 📱 Responsive Layout:

```
┌─────────────────────────────────────┐  ┌─────────────────┐
│           TABLET                    │  │    PHONE        │
│  (Portrait - same as phone)         │  │  (Portrait)     │
│                                     │  │                 │
│  ┌─────────────────────────────┐   │  │ ┌─────────────┐ │
│  │                             │   │  │ │   HEADER    │ │
│  │      [CARDS STACK]          │   │  │ ├─────────────┤ │
│  │                             │   │  │ │    CARD 1   │ │
│  │  Full width cards           │   │  │ ├─────────────┤ │
│  │  Padding: 16px              │   │  │ │    CARD 2   │ │
│  │                             │   │  │ ├─────────────┤ │
│  │                             │   │  │ │    CARD 3   │ │
│  └─────────────────────────────┘   │  │ └─────────────┘ │
│                                     │  │                 │
│  Max width: 600px (centered)       │  │ Scrollable      │
└─────────────────────────────────────┘  └─────────────────┘
```

---

## 🎯 İnteraktiv Elementlər Siyahısı:

| # | Element | Tip | Basanda Nə Olur |
|---|---------|-----|-----------------|
| 1 | 🔄 Refresh icon | `IconButton` | Status yenilənir |
| 2 | ⋮ More | `IconButton` | Digər seçimlər (gələcəkdə) |
| 3 | ☁️ Azure-a Keç | `ElevatedButton` | Confirmation dialog açılır |
| 4 | 🗄️ Öz Sistemə Qayıt | `ElevatedButton` | Confirmation dialog açılır |
| 5 | Pull down | `RefreshIndicator` | Bütün data yenilənir |
| 6 | Badge (Öz Sistem) | `Container` | Status göstərir (dekorativ) |
| 7 | Badge (Azure) | `Container` | Status göstərir (dekorativ) |

---

## 💡 UX Aksesuarları:

```
✅ Loading States:
   - CircularProgressIndicator (hər kart üçün ayrı)
   - Blocking dialog (əməliyyat zamanı)

✅ Error Handling:
   - Qırmızı error card
   - SnackBar (bottom)
   - Refresh button

✅ Success Feedback:
   - Yaşıl SnackBar
   - "OK" action button
   - Auto-dismiss

✅ Visual Hierarchy:
   - Gradient header (attention)
   - Card elevation (2dp)
   - Icon colors (semantic)
   - Badge contrast

✅ Accessibility:
   - Icon + Text combinations
   - Color not only indicator
   - Clear button labels
```
